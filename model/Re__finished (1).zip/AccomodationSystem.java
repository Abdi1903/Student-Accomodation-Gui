/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uweaccomodationsystem.model;
import java.util.ArrayList;

/**
 *
 * @author 44750
 */
public class AccomodationSystem {    
    private ArrayList<Hall> halls;
    private ArrayList<HallWarden> hallWardens;
    private HallManager hallManager;
    
    public AccomodationSystem(){
        halls = new ArrayList<Hall>();
        hallWardens = new ArrayList<HallWarden>();
        hallManager = null;
    }
    
    public void addHall(Hall hall)
    {
        halls.add(hall);
    }
    
    public ArrayList<Hall> getHalls()
    {
        return halls;
    }
    
    public ArrayList<HallWarden> getHallWardens ()
    {
        return hallWardens;
    }
    
    public void addHallWarden(HallWarden hallWarden)
    {
        hallWardens.add(hallWarden);
    }
    
    public void setHallManager(HallManager hallManager)
    {
        this.hallManager = hallManager;
    }
    
    public HallManager getHallManager()
    {
        return hallManager;
    }
    
    public void generateData ()
    {
        
    }
}
